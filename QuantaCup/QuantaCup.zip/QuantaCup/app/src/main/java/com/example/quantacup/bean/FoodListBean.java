package com.example.quantacup.bean;

public class FoodListBean {
    private String img;
    private String foodName;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setGameName(String gameName) {
        this.foodName = gameName;
    }
}
