package com.example.quantacup;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;


public class DietFragment extends Fragment {

    private LinearLayout layout;
    private LinearLayout layout1;
    private ViewPager2 viewPager2;
    private ViewPager2 viewPager3;
    private Carousel carousel;
    private Carousel carousel1;
    LinearLayout search_view;
    LinearLayout food_view;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_diet, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        viewPager2 = requireActivity().findViewById(R.id.viewPager2);
        layout = requireActivity().findViewById(R.id.index_dot);
        carousel = new Carousel(getContext(), layout, viewPager2);
        carousel.initViews(new int[]{R.drawable.red_dot,R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.grey_dot});
        carousel.startAutoScroll();

        viewPager3 = requireActivity().findViewById(R.id.viewPager3);
        layout1 = requireActivity().findViewById(R.id.index_dot1);
        carousel1 = new Carousel(getContext(), layout1, viewPager3);
        carousel1.initViews(new int[]{R.drawable.red_dot,R.drawable.d,R.drawable.e,R.drawable.f,R.drawable.grey_dot});
        carousel1.startAutoScroll();


        search_view = requireActivity().findViewById(R.id.search_view);
        search_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                if (id == R.id.search_view) {
                    Intent intent = new Intent(getContext(), SearchActivity.class);
                    startActivity(intent);
                }
            }
        });

        food_view = requireActivity().findViewById(R.id.food_view);
        food_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                if (id == R.id.food_view) {
                    Intent intent = new Intent(getContext(), DetailActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

}