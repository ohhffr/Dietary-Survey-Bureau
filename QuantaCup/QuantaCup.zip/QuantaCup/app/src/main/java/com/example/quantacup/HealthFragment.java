package com.example.quantacup;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.quantacup.R;

import java.util.zip.Inflater;


public class HealthFragment extends Fragment implements View.OnClickListener {


    RelativeLayout data_btn,condition_btn,clock_btn;  //预算中心,使用帮助,关于我们,设置
    LinearLayout search_view;


    @SuppressLint("MissingInflatedId")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_health, container, false);

        return view;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        data_btn = requireActivity().findViewById(R.id.data_btn);
        condition_btn = requireActivity().findViewById(R.id.condition_btn);
        clock_btn = requireActivity().findViewById(R.id.clock_btn);
        search_view = requireActivity().findViewById(R.id.search_view);

        data_btn.setOnClickListener(this);
        condition_btn.setOnClickListener(this);
        clock_btn.setOnClickListener(this);
        search_view.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.data_btn) {//食卡数据
            Intent intent1 = new Intent(getContext(), DataActivity.class);
            startActivity(intent1);
        } else if (id == R.id.condition_btn) {//我的状态
            Intent intent2 = new Intent(getContext(), ConditionActivity.class);
            startActivity(intent2);
        } else if (id == R.id.clock_btn) {//定时提醒
            Intent intent3 = new Intent(getContext(), ClockActivity.class);
            startActivity(intent3);
        }
        else if (id == R.id.search_view) {
            Intent intent4 = new Intent(getContext(), SearchActivity.class);
            startActivity(intent4);
        }
    }



}