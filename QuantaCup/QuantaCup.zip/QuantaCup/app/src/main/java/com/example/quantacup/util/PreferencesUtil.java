package com.example.quantacup.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.io.IOException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

public class PreferencesUtil {
    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String KEY_NAME = "myKey";

    // 写入数据
    public static void setPassword(Context context, String password, String value) throws CertificateException, IOException, NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        Key key = keyStore.getKey(KEY_NAME, null);
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        editor.putString("password", Base64.encodeToString(key.getEncoded(), Base64.DEFAULT));
        editor.commit();
        editor.commit();
    }

    // 读取数据
    public static String getPassword(Context context ) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        Key key = keyStore.getKey(KEY_NAME, null);
        String password = Base64.encodeToString(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString("password", "").getBytes(), Base64.DEFAULT);
        return password;
    }
}
