package com.example.quantacup;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class RegisterActivity extends AppCompatActivity {

    EditText number = null;
    EditText password = null;
    EditText password2 = null;
    EditText captcha =null;
    Button btn_register = null ;
    private Toolbar toolbar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        password = findViewById(R.id.password);
        password2 = findViewById(R.id.password2);
        number = findViewById(R.id.number);
        captcha =findViewById(R.id.captcha);
        btn_register =findViewById(R.id.btn_register);
        toolbar = findViewById(R.id.tb_login_btn);


        initToolbar();
    }

    public void onClick(View v) {
        String passwordstring = password.getText().toString();
        String password2string = password2.getText().toString();
        String numberstring = number.getText().toString();
        String captchastring = captcha.getText().toString();
        if (v.getId() == R.id.btn_register) {
            if (TextUtils.isEmpty(numberstring) || TextUtils.isEmpty(passwordstring) || TextUtils.isEmpty(password2string) || TextUtils.isEmpty(captchastring)) {
                Toast.makeText(RegisterActivity.this, "各项不能为空", Toast.LENGTH_SHORT).show();
            } else {
                if (TextUtils.equals(passwordstring, password2string)) {
                    SaveInfo.SaveInformation(RegisterActivity.this, numberstring, passwordstring, password2string, captchastring);
                    Toast.makeText(RegisterActivity.this, "注册成功，请返回登陆", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(RegisterActivity.this, "两次密码不一样，请重新输入", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    private void initToolbar(){

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.black), PorterDuff.Mode.SRC_ATOP);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}

