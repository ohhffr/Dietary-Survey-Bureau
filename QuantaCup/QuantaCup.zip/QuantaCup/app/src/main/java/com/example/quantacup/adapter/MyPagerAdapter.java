package com.example.quantacup.adapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.quantacup.MyFragment;

public class MyPagerAdapter extends FragmentStateAdapter {

    private final String[] tabTitles = new String[]{"主食", "奶类制品", "蔬菜", "肉类", "海鲜类", "谷类", "水果", "豆类坚果", "零食饮料"};

    public MyPagerAdapter(FragmentActivity fa) {
        super(fa);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // 根据position返回不同的Fragment
        return MyFragment.newInstance(tabTitles[position]);
    }

    @Override
    public int getItemCount() {
        return tabTitles.length;
    }

    @Nullable
    public CharSequence getPageTitle(int position) {
        return tabTitles[position];
    }
}
