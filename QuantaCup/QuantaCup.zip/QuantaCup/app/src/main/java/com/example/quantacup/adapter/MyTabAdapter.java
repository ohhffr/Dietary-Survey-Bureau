package com.example.quantacup.adapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import q.rorbin.verticaltablayout.adapter.TabAdapter;
import q.rorbin.verticaltablayout.widget.TabView;

public class MyTabAdapter implements TabAdapter {

    List<String> menus;

    public MyTabAdapter() {
        menus = new ArrayList<>();
        Collections.addAll(menus, "主食", "奶类制品", "蔬菜", "肉类", "海鲜类",
                "谷类", "水果","豆类坚果","零食饮料");
    }

    @Override
    public int getCount() {
        return menus.size();
    }

    @Override
    public TabView.TabBadge getBadge(int position) {
        return null;
    }

    @Override
    public TabView.TabIcon getIcon(int position) {
        return null;
    }

    @Override
    public TabView.TabTitle getTitle(int position) {
        return new TabView.TabTitle.Builder()
                .setContent(menus.get(position))
                .setTextColor(0xFFFFFFFF, 0xFF333333)//可自己设置tab字体颜色
                .build();
    }

    @Override
    public int getBackground(int position) {
        return -1;
    }

}
