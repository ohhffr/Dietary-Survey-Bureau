package com.example.quantacup.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quantacup.R;
import com.google.android.material.tabs.TabLayout;

public class TabAdapter extends RecyclerView.Adapter<TabAdapter.TabViewHolder> {

    private final String[] tabTitles;
    private final OnTabItemSelectedListener onTabItemSelectedListener;
    public int selectedPosition = 0;

    public interface OnTabItemSelectedListener {
        void onTabItemSelected(int position);
    }

    public TabAdapter(String[] tabTitles, OnTabItemSelectedListener onTabItemSelectedListener) {
        this.tabTitles = tabTitles;
        this.onTabItemSelectedListener = onTabItemSelectedListener;
    }

    @NonNull
    @Override
    public TabViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tab_item, parent, false);
        return new TabViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TabViewHolder holder, int position) {
        holder.tabText.setText(tabTitles[position]);
        holder.itemView.setSelected(selectedPosition == position);
        holder.itemView.setOnClickListener(v -> {
            int previousPosition = selectedPosition;
            selectedPosition = holder.getAdapterPosition();
            notifyItemChanged(previousPosition);
            notifyItemChanged(selectedPosition);
            onTabItemSelectedListener.onTabItemSelected(selectedPosition);
        });

        if (selectedPosition == position) {
            holder.tabText.setTextSize(20); // 选中时的字体大小
        } else {
            holder.tabText.setTextSize(14); // 未选中时的字体大小
        }
    }

    @Override
    public int getItemCount() {
        return tabTitles.length;
    }

    static class TabViewHolder extends RecyclerView.ViewHolder {
        TextView tabText;

        TabViewHolder(@NonNull View itemView) {
            super(itemView);
            tabText = itemView.findViewById(R.id.tab_item_text);
        }
    }
}