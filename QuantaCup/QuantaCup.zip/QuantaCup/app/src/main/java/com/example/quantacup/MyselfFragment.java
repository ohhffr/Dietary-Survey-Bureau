package com.example.quantacup;

import android.annotation.SuppressLint;

import android.content.Intent;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.example.quantacup.myself.CouponActivity;
import com.example.quantacup.myself.OrderActivity;
import com.example.quantacup.myself.ShoppingActivity;
import com.example.quantacup.myself.StarActivity;


public class MyselfFragment extends Fragment implements View.OnClickListener {


    RelativeLayout communicate_btn, usehelp_btn, about_btn, set_btn, privacy_btn, update_btn;  //预算中心,使用帮助,关于我们,设置

    Button btn_coupon,btn_star,btn_shopping,btn_order,btn_myself;


    @SuppressLint("MissingInflatedId")
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_myself, container, false);

        communicate_btn = view.findViewById(R.id.communicate_btn);
        usehelp_btn = view.findViewById(R.id.usehelp_btn);
        about_btn = view.findViewById(R.id.about_btn);
        set_btn = view.findViewById(R.id.set_btn);
        privacy_btn = view.findViewById(R.id.privacy_btn);
        update_btn = view.findViewById(R.id.update_btn);

        communicate_btn.setOnClickListener(this);
        usehelp_btn.setOnClickListener(this);
        about_btn.setOnClickListener(this);
        set_btn.setOnClickListener(this);
        privacy_btn.setOnClickListener(this);
        update_btn.setOnClickListener(this);




        btn_coupon = view.findViewById(R.id.btn_coupon);
        btn_order = view.findViewById(R.id.btn_order);
        btn_star = view.findViewById(R.id.btn_star);
        btn_shopping = view.findViewById(R.id.btn_shopping);

        btn_coupon.setOnClickListener(this);
        btn_star.setOnClickListener(this);
        btn_shopping.setOnClickListener(this);
        btn_order.setOnClickListener(this);


        btn_myself = view.findViewById(R.id.btn_myself);
        btn_myself.setOnClickListener(this);

        return view;

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.communicate_btn) {//预算中心
            Intent intent2 = new Intent(getContext(), CommunicateActivity.class);
            startActivity(intent2);
        } else if (id == R.id.usehelp_btn) {//使用帮助
            Intent intent3 = new Intent(getContext(), UsehelpActivity.class);
            startActivity(intent3);
        } else if (id == R.id.about_btn) {//关于我们
            Intent intent4 = new Intent(getContext(), AboutActivity.class);
            startActivity(intent4);
        } else if (id == R.id.set_btn) {//设置
            Intent intent5 = new Intent(getContext(), SetActivity.class);
            startActivity(intent5);
        } else if (id == R.id.privacy_btn) {//隐私
            Intent intent6 = new Intent(getContext(), PrivacyActivity.class);
            startActivity(intent6);
        } else if (id == R.id.update_btn) {//更新
            Intent intent7 = new Intent(getContext(), UpdateActivity.class);
            startActivity(intent7);
        } else if (id == R.id.btn_coupon){
            Intent intent8 = new Intent(getContext(), CouponActivity.class);
            startActivity(intent8);
        }
        else if (id == R.id.btn_star){
            Intent intent8 = new Intent(getContext(), StarActivity.class);
            startActivity(intent8);
        }
        else if (id == R.id.btn_shopping){
            Intent intent8 = new Intent(getContext(), ShoppingActivity.class);
            startActivity(intent8);
        }
        else if (id == R.id.btn_order){
            Intent intent8 = new Intent(getContext(), OrderActivity.class);
            startActivity(intent8);
        }
        else if (id == R.id.btn_myself){
            Intent intent9 = new Intent(getContext(), LoginActivity.class);
            startActivity(intent9);
        }
    }
}

    //签到功能的实现
//    public void setSignup(){
//
//
//
//        int count = Integer.parseInt(clock_day.getText().toString())+1;
//
//        editor = sp.edit();
//        editor.putString("tice",Integer.toString(count));
//        editor.commit(); //写入
//        onResume();//刷新
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//        SharedPreferences sp =getActivity().getSharedPreferences("tice",Context.MODE_PRIVATE);
//        clock_day.setText(sp.getString("tice","0"));
//    }
//}