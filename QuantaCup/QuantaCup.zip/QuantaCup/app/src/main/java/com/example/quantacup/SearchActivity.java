package com.example.quantacup;

import android.annotation.SuppressLint;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.quantacup.adapter.MyPagerAdapter;
import com.example.quantacup.adapter.TabAdapter;


public class SearchActivity extends AppCompatActivity {

    @Nullable
    private Bundle savedInstanceState;

    private Toolbar toolbar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_search);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ViewPager2 viewPager = findViewById(R.id.view_pager);
        RecyclerView tabRecyclerView = findViewById(R.id.tab_recycler_view);

        // 设置ViewPager的Adapter
        MyPagerAdapter adapter = new MyPagerAdapter(this);
        viewPager.setAdapter(adapter);

        // 设置RecyclerView的Adapter
        String[] tabTitles = new String[]{"主食", "奶类制品", "蔬菜", "肉类", "海鲜类", "谷类", "水果", "豆类坚果", "零食饮料"};
        TabAdapter tabAdapter = new TabAdapter(tabTitles, position -> viewPager.setCurrentItem(position, true));
        tabRecyclerView.setAdapter(tabAdapter);
        tabRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        // 设置ViewPager的回调
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                tabAdapter.notifyItemChanged(tabAdapter.selectedPosition);
                tabAdapter.selectedPosition = position;
                tabAdapter.notifyItemChanged(position);
            }
        });

        toolbar = findViewById(R.id.tb_search_btn);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.black), PorterDuff.Mode.SRC_ATOP);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }


}
