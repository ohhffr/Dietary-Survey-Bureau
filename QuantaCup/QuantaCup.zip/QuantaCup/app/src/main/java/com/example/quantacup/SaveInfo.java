package com.example.quantacup;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class SaveInfo {
    public static boolean SaveInformation(Context context,String number,String password,String password2,String captcha){
        try{
            FileOutputStream fos=context.openFileOutput("data.txt",Context.MODE_APPEND);
            fos.write(( "用户名："+ number +"密码：" + password + "验证码：" + captcha).getBytes());
            fos.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static Map<String,String> getSaveInformation(Context context){
        try{
            FileInputStream fis=context.openFileInput("data.txt");
            BufferedReader br= new BufferedReader(new InputStreamReader(fis));
            String str=br.readLine();
            String[] infos=str.split("用户名："+"密码："+"验证码：");
            Map<String,String> map=new HashMap<String,String>();
            map.put("number",infos[0]);
            map.put("password",infos[1]);
            fis.close();
            return map;
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
