package com.example.quantacup;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class homeFragment2 extends Fragment {

    String titleString;
    List<String> infoDataList = new ArrayList<>();


    public void setTitleString(String titleString) {
        this.titleString = titleString;
    }


    public void setinfoDataList(List<String> textList) {
        this.infoDataList = textList;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 加载 Fragment 的布局文件
        View view = inflater.inflate(R.layout.viewpage, container, false);

        // 在这里添加代码，例如初始化视图、绑定数据等等

        TextView textView = (TextView) view.findViewById(R.id.textView);

//        设置数据
        textView.setText("123");//这里可以根据设置的titleString设置每个页面的显示文字不同





        return view;
    }

}
